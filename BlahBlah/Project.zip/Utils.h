#pragma once
#include "String.h"

class Utils
{
public:
    static String itoa(uint32_t value);
};
