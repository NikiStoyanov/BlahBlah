// Nikolay Stoyanov 2MI0600435

#include "ChatSystem.h"

int main()
{
	ChatSystem system;

	system.run();
}
