// Nikolay Stoyanov 2MI0600435

#pragma once

class ChatSystem
{
public:
	void run();
};

